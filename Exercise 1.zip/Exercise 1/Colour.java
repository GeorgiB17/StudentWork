package de.unistuttgart.iste.sqa.pse.sheet10.homework.exercise1;

/**
 * provides for the different playing colours.
 * 
 * @author Sven Naber
 * @version 1.0
 */
public enum Colour {
    RED,
    BLUE,
    YELLOW,
    GREEN

}
