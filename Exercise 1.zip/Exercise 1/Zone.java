package de.unistuttgart.iste.sqa.pse.sheet10.homework.exercise1;

/**
 * provides for the different types of fields.
 * 
 * @author Sven Naber
 * @version 1.0
 */
public enum Zone {
    START,
    FIELD,
    GOAL
}
